 /*
 * A Tic Tac Toe Game for 2 players
 * PROJECT NAME: TIC TAC TOE GAME
 * PACKAGE NAME: TicTacToeGameGROUP4
 * CLASS NAME: TicTacToeGameGROUP4
 * CREATED BY: Group 4 of ICT11
 */

package TicTacToeGameGROUP4;

import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class TicTacToeGameGROUP4 extends javax.swing.JFrame {
    JLabel label = new JLabel("Tic Tac Toe");
    
    public TicTacToeGameGROUP4() {
        initComponents();
    }
        private String start = "X";
        private int X = 0;
        private int O = 0;
        // Defining the purpose of "X" and "O"
        
        private void score()
    {
        Player1.setText(String.valueOf(X));
        Player2.setText(String.valueOf(O));
        // This will display the scores after each game
    }
        private void choosePlayer()
    {
        if(start.equalsIgnoreCase("X"))
        {
            start = "O";
        }
        else
        {
            start = "X";
        }
        // This shows the symbols "X" and "O" alternately
    }
        
    private void winner()
    {   // This will emphasize the winner of the game
        String btn1 = jButton1.getText();
        String btn2 = jButton2.getText();
        String btn3 = jButton3.getText();
       
        String btn4 = jButton4.getText();
        String btn5 = jButton5.getText();
        String btn6 = jButton6.getText();
        
        String btn7 = jButton7.getText();
        String btn8 = jButton8.getText();
        String btn9 = jButton9.getText();
            
    // PLAYER 1 (X)
    // This code will emphasize the win of Player 1
        if(btn1 == ("X") && btn2 == ("X") && btn3 == ("X"))
        {
            X++;
            score();
            
            jButton1.setBackground(Color.black);
            jButton2.setBackground(Color.black);
            jButton3.setBackground(Color.black);
        }
        if(btn4 == ("X") && btn5 == ("X") && btn6 == ("X"))
        {
            X++;
            score();
            
            jButton4.setBackground(Color.black);
            jButton5.setBackground(Color.black);
            jButton6.setBackground(Color.black);
        }
        if(btn7 == ("X") && btn8 == ("X") && btn9 == ("X"))
        {
            X++;
            score();
            
            jButton7.setBackground(Color.black);
            jButton8.setBackground(Color.black);
            jButton9.setBackground(Color.black);
        }
        if(btn1 == ("X") && btn5 == ("X") && btn9 == ("X"))
        {
            X++;
            score();
            
            jButton1.setBackground(Color.black);
            jButton5.setBackground(Color.black);
            jButton9.setBackground(Color.black);
        }
        if(btn3 == ("X") && btn5 == ("X") && btn7 == ("X"))
        {
            X++;
            score();
            
            jButton3.setBackground(Color.black);
            jButton5.setBackground(Color.black);
            jButton7.setBackground(Color.black);
        }
        if(btn1 == ("X") && btn4 == ("X") && btn7 == ("X"))
        {
            X++;
            score();
            
            jButton1.setBackground(Color.black);
            jButton4.setBackground(Color.black);
            jButton7.setBackground(Color.black);
        }
        if(btn2 == ("X") && btn5 == ("X") && btn8 == ("X"))
        {
            X++;
            score();
            
            jButton2.setBackground(Color.black);
            jButton5.setBackground(Color.black);
            jButton8.setBackground(Color.black);
        }
        if(btn3 == ("X") && btn6 == ("X") && btn9 == ("X"))
        {
            X++;
            score();
            
            jButton3.setBackground(Color.black);
            jButton6.setBackground(Color.black);
            jButton9.setBackground(Color.black);
        }
        
    // PLAYER 2 (O)
    // This code will emphasize the win of Player 2
        if(btn1 == ("O") && btn2 == ("O") && btn3 == ("O"))
        {
            O++;
            score();
            
            jButton1.setBackground(Color.black);
            jButton2.setBackground(Color.black);
            jButton3.setBackground(Color.black);
        }
        if(btn4 == ("O") && btn5 == ("O") && btn6 == ("O"))
        {
            O++;
            score();
            
            jButton4.setBackground(Color.black);
            jButton5.setBackground(Color.black);
            jButton6.setBackground(Color.black);
        }
        if(btn7 == ("O") && btn8 == ("O") && btn9 == ("O"))
        {
            O++;
            score();
            
            jButton7.setBackground(Color.black);
            jButton8.setBackground(Color.black);
            jButton9.setBackground(Color.black);
        }
        if(btn1 == ("O") && btn5 == ("O") && btn9 == ("O"))
        {
            O++;
            score();
            
            jButton1.setBackground(Color.black);
            jButton5.setBackground(Color.black);
            jButton9.setBackground(Color.black);
        }
        if(btn3 == ("O") && btn5 == ("O") && btn7 == ("O"))
        {
            O++;
            score();
            
            jButton3.setBackground(Color.black);
            jButton5.setBackground(Color.black);
            jButton7.setBackground(Color.black);
        }
        if(btn1 == ("O") && btn4 == ("O") && btn7 == ("O"))
        {
            O++;
            score();
            
            jButton1.setBackground(Color.black);
            jButton4.setBackground(Color.black);
            jButton7.setBackground(Color.black);
        }
        if(btn2 == ("O") && btn5 == ("O") && btn8 == ("O"))
        {
            O++;
            score();
            
            jButton2.setBackground(Color.black);
            jButton5.setBackground(Color.black);
            jButton8.setBackground(Color.black);
        }
        if(btn3 == ("O") && btn6 == ("O") && btn9 == ("O"))
        {
            O++;
            score();
            
            jButton3.setBackground(Color.black);
            jButton6.setBackground(Color.black);
            jButton9.setBackground(Color.black);
        }
    }
    
    
//-----------------------------------------------------------------------------
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Player1 = new javax.swing.JTextField();
        Player2 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 5));

        jButton1.setBackground(new java.awt.Color(153, 153, 153));
        jButton1.setFont(new java.awt.Font("Haettenschweiler", 1, 36)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(153, 153, 153));
        jButton4.setFont(new java.awt.Font("Haettenschweiler", 1, 36)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton7.setBackground(new java.awt.Color(153, 153, 153));
        jButton7.setFont(new java.awt.Font("Haettenschweiler", 1, 36)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setBackground(new java.awt.Color(153, 153, 153));
        jButton8.setFont(new java.awt.Font("Haettenschweiler", 1, 36)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(153, 153, 153));
        jButton5.setFont(new java.awt.Font("Haettenschweiler", 1, 36)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(153, 153, 153));
        jButton2.setFont(new java.awt.Font("Haettenschweiler", 1, 36)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton9.setBackground(new java.awt.Color(153, 153, 153));
        jButton9.setFont(new java.awt.Font("Haettenschweiler", 1, 36)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(153, 153, 153));
        jButton6.setFont(new java.awt.Font("Haettenschweiler", 1, 36)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(153, 153, 153));
        jButton3.setFont(new java.awt.Font("Haettenschweiler", 1, 36)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton5)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton3)
                            .addComponent(jButton6)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton9)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jButton1, jButton2, jButton3, jButton4, jButton5, jButton6, jButton7, jButton8, jButton9});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton3)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton5)
                    .addComponent(jButton4)
                    .addComponent(jButton6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton9, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton8)
                    .addComponent(jButton7))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jButton1, jButton2, jButton3, jButton4, jButton5, jButton6, jButton7, jButton8, jButton9});

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 5));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Haettenschweiler", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 34, 177));
        jLabel1.setText("Score:");

        Player1.setFont(new java.awt.Font("Haettenschweiler", 0, 18)); // NOI18N

        Player2.setFont(new java.awt.Font("Haettenschweiler", 0, 18)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Haettenschweiler", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Player 001 (X):");

        jLabel4.setFont(new java.awt.Font("Haettenschweiler", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Player 002 (O):");

        jButton11.setBackground(new java.awt.Color(153, 153, 153));
        jButton11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton11.setText("Play again");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton10.setBackground(new java.awt.Color(153, 153, 153));
        jButton10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton10.setText("Exit");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Player1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)
                            .addComponent(Player2, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton10, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(20, 20, 20))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jButton10, jButton11});

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {Player1, Player2});

        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Player1, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE))
                .addGap(30, 30, 30)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Player2))
                .addGap(29, 29, 29))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {Player1, Player2, jButton10, jButton11});

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 5));

        jLabel2.setFont(new java.awt.Font("Haettenschweiler", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 34, 177));
        jLabel2.setText("TIC - TAC - TOE");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(145, 145, 145)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel2))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
//-----------------------------------------------------------------------------
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // This button shall show "X" or "O", whichever comes first 
        jButton1.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            start = "O";
        }
        else
        {
            start = "X";
        }
        choosePlayer();
        
         jButton1.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            jButton1.setForeground(Color.magenta);
        }
        else
        {
            jButton1.setForeground(Color.GREEN);
        }
        choosePlayer();
        winner();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // This button shall show "X" or "O", whichever comes first 
        jButton2.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            start = "O";
        }
        else
        {
            start = "X";
        }
        choosePlayer();
        
        jButton2.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            jButton2.setForeground(Color.magenta);
        }
        else
        {
            jButton2.setForeground(Color.GREEN);
        }
        choosePlayer();
        winner();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // This button shall show "X" or "O", whichever comes first 
        jButton3.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            start = "O";
        }
        else
        {
            start = "X";
        }
        choosePlayer();
        
        jButton3.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            jButton3.setForeground(Color.magenta);
        }
        else
        {
            jButton3.setForeground(Color.GREEN);
        }
        choosePlayer();
        winner();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // This button shall show "X" or "O", whichever comes first 
        jButton4.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            start = "O";
        }
        else
        {
            start = "X";
        }
        choosePlayer();
        
        jButton4.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            jButton4.setForeground(Color.magenta);
        }
        else
        {
            jButton4.setForeground(Color.GREEN);
        }
        choosePlayer();
        winner();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // This button shall show "X" or "O", whichever comes first 
        jButton5.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            start = "O";
        }
        else
        {
            start = "X";
        }
        choosePlayer();
        
        jButton5.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            jButton5.setForeground(Color.magenta);
        }
        else
        {
            jButton5.setForeground(Color.GREEN);
        }
        choosePlayer();
        winner();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // This button shall show "X" or "O", whichever comes first 
        jButton6.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            start = "O";
        }
        else
        {
            start = "X";
        }
        choosePlayer();
        
        jButton6.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            jButton6.setForeground(Color.magenta);
        }
        else
        {
            jButton6.setForeground(Color.GREEN);
        }
        choosePlayer();
        winner();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // This button shall show "X" or "O", whichever comes first 
        jButton7.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            start = "O";
        }
        else
        {
            start = "X";
        }
        choosePlayer();
        
        jButton7.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            jButton7.setForeground(Color.magenta);
        }
        else
        {
            jButton7.setForeground(Color.GREEN);
        }
        choosePlayer();
        winner();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // This button shall show "X" or "O", whichever comes first 
        jButton8.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            start = "O";
        }
        else
        {
            start = "X";
        }
        choosePlayer();
        
        jButton8.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            jButton8.setForeground(Color.magenta);
        }
        else
        {
            jButton8.setForeground(Color.GREEN);
        }
        choosePlayer();
        winner();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // This button shall show "X" or "O", whichever comes first 
        jButton9.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            start = "O";
        }
        else
        {
            start = "X";
        }
        choosePlayer();
        
        jButton9.setText(start);
        if(start.equalsIgnoreCase("X"))
        {
            jButton9.setForeground(Color.magenta);
        }
        else
        {
            jButton9.setForeground(Color.GREEN);
        }
        choosePlayer();
        winner();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // This is the exit button
        JFrame frame = new JFrame ("Exit");
        
        if(JOptionPane.showConfirmDialog(frame, "Confirm if you want Exit",
                "Tic Tac Toe", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION)
        {
            System.exit(0);
    }//GEN-LAST:event_jButton10ActionPerformed
}
    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // The Play Again button
        jButton1.setText(null);
        jButton2.setText(null);
        jButton3.setText(null);
        
        jButton4.setText(null);
        jButton5.setText(null);
        jButton6.setText(null);
        
        jButton7.setText(null);
        jButton8.setText(null);
        jButton9.setText(null);
        
        jButton1.setBackground(Color.LIGHT_GRAY);
        jButton2.setBackground(Color.LIGHT_GRAY);
        jButton3.setBackground(Color.LIGHT_GRAY);
        
        jButton4.setBackground(Color.LIGHT_GRAY);
        jButton5.setBackground(Color.LIGHT_GRAY);
        jButton6.setBackground(Color.LIGHT_GRAY);
        
        jButton7.setBackground(Color.LIGHT_GRAY);
        jButton8.setBackground(Color.LIGHT_GRAY);
        jButton9.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_jButton11ActionPerformed

//-----------------------------------------------------------------------------
    public static void main(String[] args){
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TicTacToeGameGROUP4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TicTacToeGameGROUP4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TicTacToeGameGROUP4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TicTacToeGameGROUP4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TicTacToeGameGROUP4().setVisible(true);
            }
        });
    }
    
//-----------------------------------------------------------------------------
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Player1;
    private javax.swing.JTextField Player2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
//-----------------------------------------------------------------------------

/*
 * A Tic Tac Toe Game for 2 players
 * PROJECT NAME: TIC TAC TOE GAME
 * PACKAGE NAME: TicTacToeGameGROUP4
 * CLASS NAME: TicTacToeGameGROUP4
 * CREATED BY: Group 4 of ICT11
 */