/*
 * A Tic Tac Toe Game for 2 players
 * PROJECT NAME: TIC TAC TOE GAME
 * PACKAGE NAME: TicTacToeGameGROUP4
 * CLASS NAME: TicTacToeGameGROUP4
 * CREATED BY: Group 4 of ICT11
 */

package TicTacToeGameGROUP4;

public class JOptionPane {
    // This is for the JOptionPane for the exit button
    static int YES_NO_OPTION;
}

/*
 * A Tic Tac Toe Game for 2 players
 * PROJECT NAME: TIC TAC TOE GAME
 * PACKAGE NAME: TicTacToeGameGROUP4
 * CLASS NAME: TicTacToeGameGROUP4
 * CREATED BY: Group 4 of ICT11
 */